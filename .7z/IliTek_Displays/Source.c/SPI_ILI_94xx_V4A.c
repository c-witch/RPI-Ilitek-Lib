#include "/home/pi/Desktop/CEE/Local_Includes/extrafunctions.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <stdint.h>
#include <gpiod.h>
#include <spidev.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <asm/ioctl.h>
#include <linux/spi/spidev.h>

#if!defined word
typedef unsigned short int word;
#endif
#if!defined byte
typedef unsigned char byte;
#endif
#if!defined LOW
#define LOW 0
#endif
#if!defined HIGH
#define HIGH 1
#endif
#if!defined True
#define True 1
#endif
#if!defined False
#define False 0
#endif
#if!defined ON
#define ON 1
#endif
#if!defined OFF
#define OFF 0
#endif


#define HORIZONTAL 0
#define VERTICAL 1
#define CH_ONLY 2 // character bits only to textcolor
#define CH_BG 4 // character bits to textcolor and other bits set to textbkcolor
#define CH_INV 8 // swap text and background color for characters
#define CH_UL 16 // underline characters with textcolor


#define Fill 1
#define Nofill 0
#define Degree 248
#define OpenArc 0
#define ClosedArc 1

typedef word cords[2];
cords triangle[3];

word INITBYTES;
char *errMsg[10] =
{
"OK\n",//0
"Invalid direction\n",//1
"Character off edge of screen\n",//2
"Character off bottom of screen\n",//3
"String is to long for the screen position and direction\n",//4
"X or X1 is out of range\n",//5
"Y or Y1 is out of range\n",//6

};
byte *gptr,*Rxptr,*GPTR,*RXPTR;
byte Foreground[3],Background[3],Textcolor[3],TextBkcolor[3];
word lcdWidth = 320;//480;
word lcdHeight = 240;//480;//240;//320;
word scanlinebytes;
word rotateAngle = 270;
byte bgr = 1;
unsigned int writeBytes,bytesperscreen;;
clock_t tick1,tick2, startFill, endFill, time2Fill;

//****************** Font data below ***********************************
char fontPath[128];// = ;
FILE * fontFD;
word font[16388];
//word fontPixels[16*32];
word fontWidth,fontHeight;
word fontIndex = 2;
word *txtptr;// pointer into character glyphs for char to print
byte FontControlFlag = 2;
byte GraphicsControlFlag = 0;
#define BITBLIT 1

//********************** Display data below ****************************
#define MEM_Y   (7) // MY row address order
#define MEM_X   (6) // MX column address order
#define MEM_V   (5) // MV row / column exchange
#define MEM_L   (4) // ML vertical refresh order
#define MEM_H   (2) // MH horizontal refresh order
#define MEM_BGR (3) // RGB-BGR Order

byte initArray[512];

#define iliLCDs 3
char *iliChips[iliLCDs] =
{
"ILI9341",// 7 Bytes
"ILI9486",
"ILI9488",
};
#define ILIparams 20
char *iliParams[ILIparams] =
{
"DC",
"RESET",
"LED",
"BGR",
"ROTATE",
"?",
"H",
};
#define ILIinit 3
char *iliINIT[ILIinit] =
{
"ili_9341.init",
"ili_9486.init",
"ili_9488.init",
};
//word lcdRotateIndex = 16;
//word BPPindex = 13;
char *Ili_InitPath = "/media/pi/fa69b178-3404-409f-a3db-7d0d98c660b5/16GigStick/IliTek_Displays/Init_Code/";
char initPath[255];
FILE *initFD = NULL;
word initSize;// size of initialization file in bytes
word ROTATE = 270;
byte displayRotate=0x28;
word initParamCount;
byte initList[20];
word iliINITindex = 2;
byte lcdBGR = 1;
word DC = 24;    // default DC GPIO number
word RESET = 23; // default RESET GPIO number
word LED = 18;   // default BACKLIGHT GPIO number
word lcdError;
byte *initCodePtr = NULL;
//************************ SPI data below ******************************
#define Spi00 0
#define Spi01 1
#define Spi10 2
#define Spi11 3
#define Spi12 4

static int SPIchannel = 0;
static int SPIspeed = 32000000; // MHz
static const char       *spiChannel[5] =
{
"/dev/spidev0.0",
"/dev/spidev0.1",
"/dev/spidev1.0",
"/dev/spidev1.1",
"/dev/spidev1.2",
};
static const uint8_t     spiBPW   = 8 ;
static const uint16_t    spiDelay = 0 ;
int lcdFD;
static uint32_t    spiSpeeds [5] ;
static int         spiFds [5] ;

struct gpiod_chip *pins_chip;
struct gpiod_line *Led,*Reset,*Dc;
//*************************** Init code below **************************
byte iliINITcode[512] =
{
//*********************** ili9341 init code ****************************
//
//********************** ILI9431 Init code *****************************
/*
0xff,0x01,
0xff,0x28,
0xff,0xcf,
0x00,0x83,0x30,//params
0xff,0xed,
0x64,0x03,0x12,0x81,//params
0xff,0xe8,
0x85,0x01,0x79,//params
0xff,0xcb,
0x39,0x2c,0x00,0x34,0x02,//params
0xff,0xf7,0x20,
0xff,0xea,
0x00,0x00,//params
0xff,0xc0,0x26,
0xff,0x11,
0xfe,0x78, // 120 ms timeout in case we were in sleepin mode
0xff,0xc5,
0x35,0x3e,//params
0xff,0xc7,0xbe,
0xff,0x3a,0x66,// change to 18 bit color 0x55,
0xff,0x36,0x28,// rotated 270 degree's
0xff,0xb1,
0x00,0x1b,//params
0xff,0x26,0x01,
0xff,0xb7,0x07,
0xff,0xb6,
0x0a,0x82,0x27,0x00,//params
0xff,0x11,
0xff,0x38,
0xff,0x29,
0xfd,
*/



/*
					// ili9486 init code from waveshare35a dts file works with linux frame buffer
					0xff,0x01, // soft reset
					0xff,0xb0, 0x00,
					0xff,0x11, // sleep out
					0xfe,0x78,//delay 120 ms
					0xff,0x28,// display off
					0xff,0x3a,0x66,// 18 bit color  0x55 16 bit color only on 3 wire spi
					0xff,0x36,0x28, // //0 zero = 0x88 90 = 0xf8 180 = 0x48 270 = 0x28
					0xff,0xc2,0x44,
					0xff,0xc5, 0x00, 0x00, 0x00, 0x00,
					// gamma below /
					0xff,0xe0, 0x0f, 0x1f, 0x1c, 0x0c, 0x0f, 0x08, 0x48, 0x98,  0x37, 0x0a, 0x13,  0x04,  0x11, 0x0d, 0x00,
					0xff,0xe1, 0x0f, 0x32, 0x2e, 0x0b, 0x0d, 0x05, 0x47, 0x75, 0x37, 0x06, 0x10, 0x03, 0x24, 0x20, 0x00,
					//-1,0xe2, 0x0f, 0x32, 0x2e, 0x0b, 0x0d, 0x05, 0x47, 0x75, 0x37, 0x06, 0x10, 0x03, 0x24, 0x20, 0x00,
					// piscreen -> waveshare35a /
					0xff,0x11, // sleep out
					0xfe,0x0a, // delay 10ms
					0xff,0x2A,0x0,0x0,0x01,0xdf,// set columns
					0xfe,0x10, // 10 ms delay
					0xff,0x2B,0x0,0x0,0x01,0x3f, // set rows
					0xfe,0x10, // 10 ms delay
					0xff,0x29, // display on
					0xff,0x2C, // write pixel data
					0xfd // end of init
*/
};




//************************Proto Types***********************************

// *********** Utility functions ***************************************
void EXIT(byte err);
void hardReset(void);
word swapbytes(word *valueptr);
void bitprint(word lint,word size);
word lcdOrientation(word rotation);
word stringPixels(char* str);
//************ SPI related I/O Functions *******************************
int writeCommand(byte);
int writeData(byte*,word);
//*********** Utility display functions ********************************
void lcdon(void);
void lcdoff(void);
void lcdInvert(word);
//*********** Host memory to display functions *************************
unsigned int lcdOffset(word ,word);
int bitBlt(word,word,word,word);
int lcdRefresh(void);
unsigned int lcdClear(void);
int lcdSetwindow(int,int,int,int);
//*********** Graphic primatave functions ******************************
int lcdPutpixel(word x,word y);
unsigned int lcdGetpixel(word ,word );
int lcddrawChar(word,word ,char*);
int lcddrawString(int,int,char *);
int lcddrawHline(word,word,word);
int lcddrawVline(word,word,word);
byte lcddrawLine(int ,int ,int ,int);
int lcddrawRectangle(word,word,word,word,byte);
word lcdclearArea(word,word,word,word);
byte lcddrawArc(word ,word ,word ,word ,word ,byte);
byte lcddrawCircle(word ,word ,word ,byte);
byte lcddrawEllipse(word ,word ,word ,word ,byte);
int lcdrestoreArea(word ,word ,byte *);
byte* lcdsaveArea(word ,word ,word ,word );
int lcddrawTriangle(word x0,word y0,word radius,byte type,word ang1,word ang2,word ang3);
//******************* GPIO pins ****************************************
void gpioOpen(void);
void gpioPins(void);
void gpioClose(void);
void DigitalWrite(struct gpiod_line *,word);
//******************* SPI **********************************************
int SPIGetFd (int channel);
int SPIDataRW (int channel, unsigned char *Txptr,int len);
int SPISetupMode (int channel, int speed, int mode);
int SPISetup (int channel, int speed);
//*********************** End proto types ******************************


//********************* SPI functions **********************************

int SPIGetFd (int channel)
{
	return spiFds [channel & 7] ;
}
// *********** workhorse function below does all heavy work ************
int SPIDataRW (int channel, unsigned char *Txptr,int len)
{
struct spi_ioc_transfer spi ;
short int err;

	channel &= 7 ;
	if(Rxptr!=NULL)
		memset(Rxptr,0,4096);
	memset (&spi, 0, sizeof (spi)) ;

	spi.tx_buf        = (unsigned long)Txptr ;
	spi.rx_buf        = (unsigned long)Rxptr ;
	spi.len           = len ;
	spi.delay_usecs   = spiDelay ;
	spi.speed_hz      = spiSpeeds [channel] ;
	spi.bits_per_word = spiBPW ;

	err=ioctl (spiFds [channel], SPI_IOC_MESSAGE(1), &spi) ;
	if(err<0)
	{
		printf("%d SPI write error %s\n",err,strerror(errno));
		EXIT(1);
	}
	return(0);
}

int SPISetupMode (int channel, int speed, int mode)
{
int fd ;

	mode    &= 3 ;	// Mode is 0, 1, 2 or 3
	channel &= 7 ;	// Channel is 0 to 4 ie spi0.0 spi0.1 spi1.0 spi1.1 spi1.2

	if((fd=open(spiChannel[channel],O_RDWR | O_NONBLOCK))<0)
	{
    fprintf(stderr,"%s  %d\n",spiChannel[channel],channel);
    fflush(stderr);
    printf("Unable to open SPI device: %s\n", strerror (errno));
    EXIT(2);
	}
	spiSpeeds [channel] = speed ;
	spiFds    [channel] = fd ;
	if (ioctl (fd, SPI_IOC_WR_MODE, &mode)            < 0)
	{
		printf("SPI Mode Change failure: %s\n", strerror (errno));
		EXIT(3);
	}
	if (ioctl (fd, SPI_IOC_WR_BITS_PER_WORD, &spiBPW) < 0)
	{
		printf("SPI BPW Change failure: %s\n", strerror (errno)) ;
		EXIT(4);
	}
	if (ioctl (fd, SPI_IOC_WR_MAX_SPEED_HZ, &speed)   < 0)
	{
		printf("SPI Speed Change failure: %s\n", strerror (errno)) ;
		EXIT(5);
	}
	return fd ;
}

int SPISetup (int channel, int speed)
{
	return SPISetupMode (channel, speed, 0) ;
}
//***************** End of SPI functions *******************************


// ************************** GPIO functions ***************************

void gpioOpen(void)
{
	pins_chip = gpiod_chip_open("/dev/gpiochip0");
	if (pins_chip==NULL)
	{
		printf("Fatal: Unable to open GPIO! Aborting\n");
		EXIT(2);
	}
}

void gpioClose(void)
{
	gpiod_line_set_value(Led,LOW);
	gpiod_line_release(Led);
	gpiod_line_release(Reset);
	gpiod_line_release(Dc);
	gpiod_chip_close(pins_chip);
}

void gpioPins(void)
{
word rc;

	Led = gpiod_chip_get_line(pins_chip, LED);
	if(Led==NULL)
	{
		printf("Pin unavailable\n");
		gpiod_chip_close(pins_chip);
		EXIT(3);
	}
	Reset = gpiod_chip_get_line(pins_chip, RESET);
	if(Reset==NULL)
	{
		printf("Pin unavailable\n");
		gpiod_chip_close(pins_chip);
		EXIT(3);
	}
	Dc = gpiod_chip_get_line(pins_chip, DC);
	if(Dc==NULL)
	{
		printf("Pin unavailable\n");
		gpiod_chip_close(pins_chip);
		EXIT(3);
	}
	rc=gpiod_line_request_output(Led,"led", LOW);
	if (rc<0)
	{
		gpiod_chip_close(pins_chip);
		printf("Fatal! Led Pin unavailable. Aborting\n");
		EXIT(4);
	}
	rc=gpiod_line_request_output(Reset,"reset", HIGH);
	if (rc<0)
	{
		gpiod_chip_close(pins_chip);
		printf("Fatal! Reset Pin unavailable. Aborting\n");
		EXIT(4);
	}
	rc=gpiod_line_request_output(Dc,"d/c", HIGH);
	if (rc<0)
	{
		gpiod_chip_close(pins_chip);
		printf("Fatal! D/C Pin unavailable. Aborting\n");
		EXIT(4);
	}
	return;
}

void DigitalWrite(struct gpiod_line *pin ,word value)
{
word err;

	err=gpiod_line_set_value(pin,value);
	if(err<0)
	{
		printf("Fatal error writting GPIO: %s\n",strerror(errno));
		EXIT(5);
	}
	return;
}

//********************** End GPIO functions ****************************
//
//****************** Program general functions *************************
//
word lcdOrientation(word rotation)
{
byte rotate;
word temp;

	switch(rotation)
	{
		case 0 :
			rotate=(1 << MEM_X) | (lcdBGR << MEM_BGR);
			if((ROTATE==90) || (ROTATE==270))
			{
				temp=lcdWidth;
				lcdWidth=lcdHeight;
				lcdHeight=temp;
				scanlinebytes=lcdWidth*3;
				ROTATE=0;
			}
			//initArray[lcdRotateIndex]=displayRotate;
			break;
		case 90 :
			rotate=(1 << MEM_Y) | (1 << MEM_X) |
			(1 << MEM_V) | (lcdBGR << MEM_BGR);
			//initArray[lcdRotateIndex]=displayRotate;
			if((ROTATE==0) || (ROTATE==180))
			{
				temp=lcdWidth;
				lcdWidth=lcdHeight;
				lcdHeight=temp;
				scanlinebytes=lcdWidth*3;
				ROTATE=90;
			}
			break;
		case 180 :
			rotate=(1 << MEM_Y) | (lcdBGR << MEM_BGR);
			if((ROTATE==90) || (ROTATE==270))
			{
				temp=lcdWidth;
				lcdWidth=lcdHeight;
				lcdHeight=temp;
				scanlinebytes=lcdWidth*3;
				ROTATE=180;
			}
			//initArray[lcdRotateIndex]=displayRotate;
			break;
		case 270 :
			//displayRotate=0x28;
			rotate=(1<<MEM_V) | (1 << MEM_L) | (lcdBGR << MEM_BGR);
			if((ROTATE==0) || (ROTATE==180))
			{
				temp=lcdWidth;
				lcdWidth=lcdHeight;
				lcdHeight=temp;
				scanlinebytes=lcdWidth*3;
				ROTATE=270;
			}
			//initArray[lcdRotateIndex]=displayRotate;
			break;
		default :
			printf("ERROR\n");
			return(-15);
	}
	writeCommand(0x0);// NOP
	writeCommand(0x28);//display off
	writeCommand(0x36);//command to change rotation
	writeData(&rotate,1);// rotation data
	writeCommand(0x29);//turn display on
	writeCommand(0x2c);//put display into graphic data input mode
	return(0);
}



void hardReset(void) // Hard reset of display
{
	DigitalWrite(Reset,HIGH);
	usleep(5*1000);
	DigitalWrite(Reset,LOW);
	usleep(20*1000);
	DigitalWrite(Reset,HIGH);
	usleep((150*1000));
	return;
}

void EXIT(byte err)
{
	if(gptr!=NULL)
		free(gptr);
	if(Rxptr!=NULL)
		free(Rxptr);
	kbfini();
	if(fontFD!=NULL)
		fclose(fontFD);
	if(lcdFD>0)
	{
		close(lcdFD);
	}
	if(pins_chip != NULL)
		gpioClose();
	lcdoff();
	hardReset();
	exit(err);
}

void lcdon(void)
{
	DigitalWrite(Led,HIGH);
	return;
}

void lcdoff(void)
{
	DigitalWrite(Led,LOW);
	return;
}

void lcdInvert(word mode)
{
	switch(mode)
	{
		case ON :
			writeCommand(0x21);
			break;
		case OFF :
			writeCommand(0x20);
			break;
		default :
			break;
	}
}

int sgn(int value) // used by drawline function
{
int v;
	if(value<0)
		v=-1;
	if(value==0)
		v=0;
	if(value>0)
		v=1;
	return v;
}

void color18(byte *colorptr,unsigned int color) //conv 24bit color to 18 bit
{
	*colorptr=(color>>16)&252;
	*(colorptr+1)=(color>>8)&252;
	*(colorptr+2)=color&252;
}

int lcdSetwindow(int x,int y,int x1,int y1)// set pixel location x,y and window pixel width / pixel height
{
static byte buffer[4];
word temp;

	writeCommand(0x0);
	writeCommand(0x0);
	memset(buffer,0,sizeof(buffer));
	if(x>x1)
	{
		temp=x;
		x=x1;
		x1=temp;
	}
	if(x<0)
		x=0;
	if(x1>lcdWidth-1)
		x1=lcdWidth-1;
	buffer[0]=x>>8;
	buffer[1]=x&0xff;
	buffer[2]=x1>>8;
	buffer[3]=x1&0xff;
	writeCommand(0x2A);
	writeData(&buffer[0],1);
	writeData(&buffer[1],1);
	writeData(&buffer[2],1);
	writeData(&buffer[3],1);
	memset(buffer,0,sizeof(buffer));
	if(y>y1)
	{
		temp=y;
		y=y1;
		y1=temp;
	}
	if(y<0)
		y=0;
	if(y1>lcdHeight-1)
		y1=lcdHeight-1;
	buffer[0]=y>>8;
	buffer[1]=y&0xff;
	buffer[2]=y1>>8;
	buffer[3]=y1&0xff;
	writeCommand(0x2B);
	writeData(&buffer[0],1);
	writeData(&buffer[1],1);
	writeData(&buffer[2],1);
	writeData(&buffer[3],1);
	writeCommand(0x2C);// begin pixel output @ x,y and wrap at x1 y1
	return(0);
}


int writeCommand(byte command) // write command to data spi
{
static byte c;

	c=command;
	DigitalWrite(Dc,LOW);
	usleep(1);
	SPIDataRW (SPIchannel,&c,1);
	DigitalWrite(Dc,HIGH);
	return(0);
}

int writeData(byte *txptr,word count) // write data to spi
{
	SPIDataRW (SPIchannel,txptr,count);
	return(0);
}

int lcdinitPanel(void)// initialize the display
{
int count;


	//max=sizeof(iliINITcode)/sizeof(byte);
	count=0;
	while(count<INITBYTES && (iliINITcode[count]!=0xfd))
	{
		switch(iliINITcode[count])
		{
			case 0xff :
				printf("\n");
				++count;
				printf("%02x ",iliINITcode[count]);
				writeCommand(iliINITcode[count]);
				++count;
				break;
			case 0xfe :
				++count;
				printf("\nTime out for %d mS",iliINITcode[count]);
				usleep(iliINITcode[count]*1000);
				++count;
				break;
			default :
				printf("%02x ",iliINITcode[count]);
				writeData(&iliINITcode[count],1);
				++count;
				break;
		}
	}
	printf("\n");
	return(count);
}


unsigned int lcdOffset(word x,word y)//get offset into host vid memory
{
unsigned int oset;

	oset=((y*scanlinebytes)+(x*3));
	return(oset);
}

int lcdRefresh(void)//does complete host memory to display transfer
{
unsigned int index,blocks,pblocks;
static byte* pixptr;

	lcdSetwindow(0,0,lcdWidth-1,lcdHeight-1);
	pixptr=gptr;
	blocks=bytesperscreen/4096;
	pblocks=bytesperscreen%4096;
	for(index=0;index<blocks;++index)
	{
		writeData(pixptr,4096);
		pixptr+=4096;
	}
	if(pblocks>0)
		writeData(pixptr,pblocks);
	return(0);
}

unsigned int lcdClear(void)// clears display to Background colour
{
unsigned int count,index;
static byte* pixptr;

	pixptr=gptr;
	memset(pixptr,0,bytesperscreen);
	count=lcdWidth*lcdHeight;//*lcdHeight*3;
	for(index=0;index<count;++index)
	{
		*pixptr=Background[0];
		*(pixptr+1)=Background[1];
		*(pixptr+2)=Background[2];
		pixptr+=3;
	}
	bitBlt(0,0,lcdWidth-1,lcdHeight-1);
	return(0);
}


int bitBlt(word x1,word y1,word x2,word y2)// blasts a region or full screen to display from host memory
{

static byte *pixptr,*basptr,*hostptr;
unsigned int x,y,blocks,pblocks;

	if(x1>x2)
	{
		x=x1;
		x1=x2;
		x2=x;
	}
	if(y1>y2)
	{
		y=y1;
		y1=y2;
		y2=y;
	}
	x=x2-x1+1;
	y=y2-y1+1;
//printf("X1 = %d  Y1 = %d  X2 = %d  Y2 = %d\n",x1,y1,x2,y2);
//printf("memory needed %d\n",x*y*3);
	pixptr=malloc(x*y*3);
	if(pixptr==NULL)
	{
		printf("Fatal: Unable to allocate Blit buffer aborting program\n");
		EXIT(1);
	}
	basptr=pixptr;
	writeBytes=(x2-x1+1)*(y2-y1+1)*3;
	blocks=(word)(writeBytes/4096);
	pblocks=writeBytes%4096;
	for(y=y1;y<=y2;++y)
	{
		hostptr=gptr+lcdOffset(x1,y);
		for(x=x1;x<=x2;++x)
		{
			*pixptr=*(hostptr);
			*(pixptr+1)=*(hostptr+1);
			*(pixptr+2)=*(hostptr+2);
			hostptr+=3;
			pixptr+=3;
		}
	}
	pixptr=basptr;
	lcdSetwindow(x1,y1,x2,y2);
	for(y=0;y<blocks;++y)
	{
		writeData(pixptr,4096);
		pixptr+=4096;
	}
	if(pblocks>0)
		writeData(pixptr,pblocks);
	free(basptr);
	return(0);
}

int lcdrestoreArea(word x,word y,byte *resptr)//restores area of host memory gotten with save area !! doesn't release point after doing so
{
word *intptr,width,height,lin,col;
byte*pixptr;
unsigned int oset;

	intptr=(word*)resptr;
	width=*intptr;
	height=*(intptr+1);
	if(x<0)
		return(-5);
	if(y<0)
		return(-6);
	if(x+width>lcdWidth-1)
		return(-5);
	if(y+height>lcdHeight-1)
		return(-6);
	resptr+=4;
	oset=lcdOffset(x,y);
	for(lin=0;lin<height;++lin)
	{
		pixptr=gptr+oset+(lin*scanlinebytes);
		for(col=0;col<width;++col)
		{
			*(pixptr+(col*3))=*(resptr+(col*3));
			*(pixptr+(col*3)+1)=*(resptr+(col*3)+1);
			*(pixptr+(col*3)+2)=*(resptr+(col*3)+2);
		}
	}
	bitBlt(x,y,x+width-1,y+height-1);
	return(0);
}

byte* lcdsaveArea(word x,word y,word x1,word y1)//save area of host memory to a save buffer
{
byte *pixptr,*savptr,*basptr;
word temp,width,height,lin,col,*intptr;
int oset,bytecount;

	if(x>x1)
	{
		temp=x;
		x=x1;
		x1=temp;
	}
	if(y>y1)
	{
		temp=y;
		y=y1;
		y1=temp;
	}
	if((x<0) || (x1>lcdWidth-1))
	{
		lcdError=7;
		return (NULL);
	}
	if((y<0) || (y1>lcdWidth-1))
	{
		lcdError=7;
		return(NULL);
	}
	width=x1-x+1;
	height=y1-y+1;
	bytecount=width*height*3;
	savptr=malloc(bytecount+4);
	basptr=savptr;
	if(savptr==NULL)
	{
		lcdError=14;
		return(NULL);
	}
	intptr=(word*)savptr;
	*intptr=width;
	*(intptr+1)=height;
	savptr+=4;
	oset=lcdOffset(x,y);
	for(lin=0;lin<height;++lin)
	{
		pixptr=gptr+oset+(lin*scanlinebytes);
		for(col=0;col<width;++col)
		{
			*savptr=*(pixptr+(col*3)+0);
			*(savptr+1)=*(pixptr+(col*3)+1);
			*(savptr+2)=*(pixptr+(col*3)+2);
			savptr+=3;
		}
	}
	lcdError=0;
	return(basptr);
}


int lcdPutpixel(word x,word y)// writes single pixel to host memory and dislay
{
byte *pixptr;

	pixptr=gptr+lcdOffset(x,y);
	*pixptr=Foreground[0];
	*(pixptr+1)=Foreground[1];
	*(pixptr+2)=Foreground[2];
	pixptr=Foreground;
	lcdSetwindow(x,y,x,y);
	writeData(pixptr,3);
	return(0);
}

unsigned int lcdGetpixel(word x,word y) //returns pixel colour value as unsigned int
{
byte *pixptr,*retptr;
static unsigned int retColor;

	retptr=(byte*)&retColor;
	pixptr=gptr;
	pixptr+=lcdOffset(x,y);
	*(retptr +2 )=*pixptr;
	*(retptr +1) = *(pixptr+1);
	*(retptr) = *(pixptr+2);
	return(retColor);
}

int lcddrawHline(word x1,word x2,word y1)//draws horizontal lines
{
byte static *pixptr; //this contains pointer to host memory being written
unsigned int oset;// this contains offset from host memory to starting x position from host memory
int z; // contains error code if any otherwise 0
word temp;


	if((x1<0) || (x1>lcdWidth-1))
		return(-5);
	if((y1<0) || (y1>lcdHeight-1))
		return(-6);
	if((x2<0) || (x2>lcdWidth-1))
		return(-5);
	if(x1>x2)
	{
		temp=x1;
		x1=x2;
		x2=temp;
	}
	oset=lcdOffset(x1,y1);
	pixptr=gptr+oset;
	for(z=x1;z<=x2;z++)
	{
		*(pixptr)=Foreground[0];
		*(pixptr+1)=Foreground[1];
		*(pixptr+2)=Foreground[2];
		pixptr+=3;
	}
	if(GraphicsControlFlag)
		return(0);
	else
		bitBlt(x1,y1,x2,y1);
	return(0);
}

int lcddrawVline(word x1,word y1,word y2)//draws vertical lines
{
static byte *pixptr; //this contains pointer to host memory being written
unsigned int oset;// this contains offset from host memory to starting x position from host memory
int z;
word temp;

	if((x1<0) || (x1>lcdWidth-1))
		return(-5);
	if((y1<0) || (y1>lcdHeight-1))
		return(-6);
	if((y2<0) || (y2>lcdHeight-1))
		return -6;
	if(y1>y2)
	{
		temp=y1;
		y1=y2;
		y2=temp;
	}
	oset=lcdOffset(x1,y1);
	pixptr=gptr+oset;
	for(z=y1;z<=y2;z++)
	{
		*pixptr=Foreground[0];
		*(pixptr+1)=Foreground[1];
		*(pixptr+2)=Foreground[2];
		pixptr+=scanlinebytes;
	}
	if(GraphicsControlFlag)
		return(0);
	else
		bitBlt(x1,y1,x1,y2);
	return(0);
	lcdRefresh();
	return(0);
}

int lcddrawRectangle(word x1,word y1,word x2,word y2,byte mode)//draws rectangles filled or not
{
word temp, y;

	if((x1<0) || (x1>lcdWidth-1))
		return(-5);
	if((x2<0) || (x2>lcdWidth-1))
		return(-5);
	if((y1<0) || (y1>lcdHeight-1))
		return(-5);
	if((y2<0) || (y2>lcdHeight-2))
		return(-5);
	if(x1>x2)
	{
		temp=x1;
		x1=x2;
		x2=temp;
	}
	if(y1>y2)
	{
		temp=y1;
		y1=y2;
		y2=temp;
	}
	GraphicsControlFlag |= BITBLIT;
	switch(mode)
	{
		case Nofill:
			lcddrawHline(x1,x2,y1);
			lcddrawHline(x1,x2,y2);
			lcddrawVline(x1,y1,y2);
			lcddrawVline(x2,y1,y2);
			break;
		case Fill :
			for(y=y1;y<=y2;++y)
				lcddrawHline(x1,x2,y);
			break;
		default :
			return(-7);
	}
	GraphicsControlFlag ^= BITBLIT;
	bitBlt(x1,y1,x2,y2);
	return(0);
}

word lcdclearArea(word x1,word y1,word x2,word y2)//clears area of host memory and display with Foreground colour
{
byte saveColor[3];
word temp,z;

	if((x1<0) || (x1>lcdWidth-1))
		return(-5);
	if((x2<0) || (x2>lcdWidth-1))
		return(-5);
	if((y1<0) || (y1>lcdHeight-1))
		return(-6);
	if((y2<0) || (y2>lcdHeight-1))
		return(-6);
	if(x1>x2)
	{
		temp=x1;
		x1=x2;
		x2=temp;
	}
	if(y1>y2)
	{
		temp=y1;
		y1=y2;
		y2=temp;
	}
	for(z=0;z<3;++z)
	{
		saveColor[z]=Foreground[z];
		Foreground[z]=Background[z];
	}
	lcddrawRectangle(x1,y1,x2,y2,Fill);
	for(z=0;z<3;++z)
		Foreground[z]=saveColor[z];
	return(0);
}

byte lcddrawArc(word x0,word y0,word start,word end,word radius,byte mode)// draws open or closed arc no fill at this time
{
int x,y,x1,y1;
//int z,startx,endx;
double radian,s_start,s_end,dstep,degree;
byte* pixptr;
word x2,y2;

	if(end==start)
		return -9;
	if((x0<0) || (x0>lcdWidth-1))
		return -5;
	if((y0<0) || (y0>lcdHeight-1))
		return -6;
	if(end<start)
		end+=360;
	if((x0-radius<0) || (x0+radius>=lcdWidth-1))
		return(-5);
	if((y0-radius<0) || (y0 +radius>=lcdHeight-1))
		return(-6);
	s_start=(double)start;
	s_end=(double)end;
	switch(mode)
	{
		case OpenArc : // arc drawn with foreground colour
		case ClosedArc :
			dstep=360.0/(2*radius*M_PI);
			s_end+=dstep;
			for(degree=s_start;degree<=s_end;degree+=dstep)
			{
				radian=deg2rad(degree);
				x=cos(radian)*(double)radius;
				y=sin(radian)*(double)radius;
				pixptr=gptr+lcdOffset((x0+x),(y0-y));
				*pixptr=Foreground[0];
				*(pixptr+1)=Foreground[1];
				*(pixptr+2)=Foreground[2];
			}
			if(mode==OpenArc)//  || (mode==ClosedArc))
				break;
			radian=deg2rad(s_start);
			x=cos(radian)*(double)radius;
			y=sin(radian)*(double)radius;
			x1=x0+x;
			y1=y0-y;
			radian=deg2rad(s_end);
			x=cos(radian)*(double)radius;
			y=sin(radian)*(double)radius;
			x2=x0+x;
			y2=y0-y;
//printf("closed arc -> X1 = %d  Y1 = %d  X2 = %d  Y2 = %d\n",x1,y1,x2,y2);
			GraphicsControlFlag |= 1;
			lcddrawLine(x1,y1,x2,y2);
			GraphicsControlFlag ^= 1;
			break;
	}// end of switch mode
	x1=x0-radius;
	y1=y0-radius;
	x2=x0+radius;
	y2=y0+radius;
	bitBlt(x1,y1,x2,y2);
	//lcdRefresh();
	return 0;
}


byte lcddrawCircle(word x0,word y0,word radius,byte mode)//draws filled or not circle to host memory then to display using foreground colour
{
int x,y,z,dx;
int c;
double radian,degree,dstep;
byte *pixptr;

	if((x0<0) || (x0>lcdWidth-1))
		return(-6);
	if((y0<0) || (y0>lcdHeight-1))
		return(-7);
	if((x0-radius<0) || (x0+radius>lcdWidth-1))
		return(-6);
	if((y0-radius<0) || (y0 +radius>lcdHeight-1))
		return(-7);
	switch(mode)
	{
		case 0 : // circle drawn with foreground colour*/
			dstep=360.0/(2*radius*M_PI);
			for(degree=0.0;degree<=90.0;degree+=dstep)
			{
				radian=deg2rad(degree);
				x=cos(radian)*(double)radius;
				y=sin(radian)*(double)radius;
				pixptr=gptr;
				pixptr+=lcdOffset(x0+x,y0-y);
				*pixptr=Foreground[0];
				*(pixptr+1)=Foreground[1];
				*(pixptr+2)=Foreground[2];
				pixptr=gptr;
				pixptr+=lcdOffset(x0-x,y0-y);
				*pixptr=Foreground[0];
				*(pixptr+1)=Foreground[1];
				*(pixptr+2)=Foreground[2];
				pixptr=gptr;
				pixptr+=lcdOffset(x0-x,y0+y);
				*pixptr=Foreground[0];
				*(pixptr+1)=Foreground[1];
				*(pixptr+2)=Foreground[2];
				pixptr=gptr;
				pixptr+=lcdOffset(x0+x,y0+y);
				*pixptr=Foreground[0];
				*(pixptr+1)=Foreground[1];
				*(pixptr+2)=Foreground[2];
			}
			break;

		case 1 : // filled circle with foreground colour
			for(z=0;z<=radius;++z)
			{
				x=sqrt((pow(radius,2)-pow(z,2)));
				dx=(x0+x)-(x0-x);
				pixptr=gptr;
				pixptr+=lcdOffset(x0-x,y0-z);
				for(c=0;c<=dx;c++)
				{
					*(pixptr+(c*3))=Foreground[0];
					*(pixptr+(c*3)+1)=Foreground[1];
					*(pixptr+(c*3)+2)=Foreground[2];
				}
				pixptr=gptr;
				pixptr+=lcdOffset(x0-x,y0+z);
				for(c=0;c<=dx;c++)
				{
					*(pixptr+(c*3))=Foreground[0];
					*(pixptr+(c*3)+1)=Foreground[1];
					*(pixptr+(c*3)+2)=Foreground[2];
				}
			}
			break;
	} // end of switch mode
	bitBlt(x0-radius,y0-radius,x0+radius,y0+radius);
	return 0;
}

byte lcddrawEllipse(word x0,word y0,word xr,word yr,byte mode)// draws filled or not ellipse to host memory then display
{
int x,y,dx,count;
double radian,degree,dstep;
byte *pixptr;

	if((x0<0) || (x0>lcdWidth-1))
		return -7;
	if((y0<0) || (y0>lcdHeight-1))
		return -7;
	if(xr==yr)
		return(lcddrawCircle(x0,y0,xr,mode));
	if((x0-xr)<0 || (x0+xr)>(lcdWidth-1))
		return -7;
	if((y0-yr)<0 || (y0+yr)>(lcdHeight-1))
		return -7;
	dstep=360.0/((float)(yr+xr)*2*M_PI);
	switch(mode)
	{
		case(Nofill):
			for(degree=0.0;degree<=90.0;degree+=dstep)
			{
				radian=deg2rad(degree);
				x=cos(radian)*(double)xr;
				y=sin(radian)*(double)yr;
				pixptr=gptr;
				pixptr+=lcdOffset(x0+x,y0-y);
				*pixptr=Foreground[0];
				*(pixptr+1)=Foreground[1];
				*(pixptr+2)=Foreground[2];
				pixptr=gptr;
				pixptr+=lcdOffset(x0-x,y0-y);
				*pixptr=Foreground[0];
				*(pixptr+1)=Foreground[1];
				*(pixptr+2)=Foreground[2];
				pixptr=gptr;
				pixptr+=lcdOffset(x0-x,y0+y);
				*pixptr=Foreground[0];
				*(pixptr+1)=Foreground[1];
				*(pixptr+2)=Foreground[2];
				pixptr=gptr;
				pixptr+=lcdOffset(x0+x,y0+y);
				*pixptr=Foreground[0];
				*(pixptr+1)=Foreground[1];
				*(pixptr+2)=Foreground[2];
			}
			break;
		case(Fill):
			for(degree=0.0;degree<=90.0;degree+=dstep)
			{
				radian=deg2rad(degree);
				x=cos(radian)*(double)xr;
				y=sin(radian)*(double)yr;
				dx=(x0+x)-(x0-x);
				for(count=0;count<=dx;count++)
				{
					pixptr=gptr;
					pixptr+=lcdOffset(x0-x,y0-y);
					*(pixptr+(count*3))=Foreground[0];
					*(pixptr+(count*3)+1)=Foreground[1];
					*(pixptr+(count*3)+2)=Foreground[2];
					pixptr=gptr;
					pixptr+=lcdOffset(x0-x,y0+y);
					*(pixptr+(count*3))=Foreground[0];
					*(pixptr+(count*3)+1)=Foreground[1];
					*(pixptr+(count*3)+2)=Foreground[2];
				}
			}
			break;
	}
	bitBlt(x0-xr,y0-yr,x0+xr,y0+yr);
	return 0;
}


byte lcddrawLine(int x1,int y1,int x2,int y2)//draws lines diagonally as well as horz or vert
{
int i,dx,dy,sdx,sdy,dxabs,dyabs,x,y,px,py;
unsigned int offset;
byte *pixptr;


	if((x1<0) || (x1>lcdWidth-1))
		return -5;
	if((x2<0) || (x2>lcdWidth-1))
		return -5;
	if((y1<0) || (y1>lcdHeight-1))
		return-6;
	if((y2<0) || (y2>lcdHeight-1))
		return-6;

	dx=x2-x1;
	dy=y2-y1;
	dxabs=abs(dx);
	dyabs=abs(dy);
	if(dx==0) // line is vertical
		return(lcddrawVline(x1,y1,y2));
	if(dy==0) // line is horizontal
		return(lcddrawHline(x1,x2,y1));
	sdx=sgn(dx);
	sdy=sgn(dy);
	x=dyabs>>1;
	y=dxabs>>1;
	px=x1;
	py=y1;
	if(dxabs>=dyabs)
	{
		for(i=0;i<dxabs;i++)
		{
			y+=dyabs;
			if(y>=dxabs)
			{
				y-=dxabs;
				py+=sdy;
			}
			px+=sdx;
			pixptr=gptr;
			offset=lcdOffset(px,py);
			pixptr+=offset;
			*(pixptr)=Foreground[0];
			*(pixptr+1)=Foreground[1];
			*(pixptr+2)=Foreground[2];
		}
	}
	else
	{
		for(i=0;i<dyabs;i++)
		{
			x+=dxabs;
			if(x>=dyabs)
			{
				x-=dyabs;
				px+=sdx;
			}
			py+=sdy;
			pixptr=gptr;
			offset=lcdOffset(px,py);
			pixptr+=offset;
			*(pixptr)=Foreground[0];
			*(pixptr+1)=Foreground[1];
			*(pixptr+2)=Foreground[2];
		}
	}
	if(GraphicsControlFlag & 1)
		return(0);
	bitBlt(x1,y1,x2,y2);
	return 0;
}
/*
*#define CH_ONLY 2 // draw character foreground only
#define CH_BG 4 // draw character with foreground and background
#define CH_INV 8 // swap text and background color for characters
#define CH_UL 16 // underline characters with textcolor

 *
*/


int lcddrawChar(word x,word y,char*k)// draws characters to host memory and display
{
unsigned int index,oset;
unsigned int err,lin;
byte col;
byte *tptr;
byte attributes = 0;
byte savcolor[3];

	if(x+fontWidth>lcdWidth-1)
	{
		err=-1;
		return(err);
	}
	if(y+fontHeight>lcdHeight-1)
	{
		err=-2;
		return(err);
	}
	index=(*k*fontHeight)+2;
	oset=lcdOffset(x,y);
	lin=2;
	for(col=0;col<3;++col)
	{
		if(FontControlFlag&(lin<<col))
			attributes=FontControlFlag&(lin<<col);
	}
	for(lin=1;lin<=fontHeight+1;++lin)
	{
		tptr=(gptr + ((lin-1)*scanlinebytes) + oset);					// sas's -3
		for(col=1; col<=fontWidth+1; col ++)						// sas's -1
		{
			switch(attributes)
			{
				case 2 :
					if(((font[index+(lin-1)]<<(col-1))&0b1000000000000000))
					{ /// normal
						*(tptr+((col-1)*3))=Textcolor[0];
						*(tptr+((col-1)*3)+1)=Textcolor[1];
						*(tptr+((col-1)*3)+2)=Textcolor[2];
					}
					break;
				case 4 :
					if(((font[index+(lin-1)]<<(col-1))&0b1000000000000000))
					{ /// foreground
						*(tptr+((col-1)*3))=Textcolor[0];
						*(tptr+((col-1)*3)+1)=Textcolor[1];
						*(tptr+((col-1)*3)+2)=Textcolor[2];
					}
					else
					{ /// background
						*(tptr+((col-1)*3))=TextBkcolor[0];
						*(tptr+((col-1)*3)+1)=TextBkcolor[1];
						*(tptr+((col-1)*3)+2)=TextBkcolor[2];
					}
					break;
				case 8 :
					if(((font[index+(lin-1)]<<(col-1))&0b1000000000000000))
					{ /// foreground
						*(tptr+((col-1)*3))=TextBkcolor[0];
						*(tptr+((col-1)*3)+1)=TextBkcolor[1];
						*(tptr+((col-1)*3)+2)=TextBkcolor[2];
					}
					else
					{ /// background
						*(tptr+((col-1)*3))=Textcolor[0];
						*(tptr+((col-1)*3)+1)=Textcolor[1];
						*(tptr+((col-1)*3)+2)=Textcolor[2];
					}
					break;
			} // end switch attributes
/*
			if(((font[index+(lin-1)]<<(col-1))&0b1000000000000000))
			{ /// normal
				*(tptr+(col*3))=Textcolor[0];
				*(tptr+(col*3)+1)=Textcolor[1];
				*(tptr+(col*3)+2)=Textcolor[2];
			}
			else
			{ /// inverse
				*(tptr+(col*3))=TextBkcolor[0];
				*(tptr+(col*3)+1)=TextBkcolor[1];
				*(tptr+(col*3)+2)=TextBkcolor[2];
			}
*/
		}//end for col
		if(!(FontControlFlag&1))
		{
			if(FontControlFlag&16)
			{
				savcolor[0]=Foreground[0];
				savcolor[1]=Foreground[1];
				savcolor[2]=Foreground[2];
				Foreground[0]=Textcolor[0];
				Foreground[1]=Textcolor[1];
				Foreground[2]=Textcolor[2];
				lcddrawHline(x,x+fontWidth,y+fontHeight);
				Foreground[0]=savcolor[0];
				Foreground[1]=savcolor[1];
				Foreground[2]=savcolor[2];
			}
		}
	}// end for lin
	if(GraphicsControlFlag)
		return(0);
	else
		bitBlt(x,y,x+fontWidth+1,y+fontHeight);
	return(0);
}


word stringPixels(char* str)// calculates required horz / vert pixels for given string length and font
{
	if(!(FontControlFlag&1))
		return(strlen(str)*fontWidth);
	else
		return(strlen(str)*fontHeight);
}

int lcddrawString(int x,int y,char * strptr)// draws string to host and display if bit one of graphicscontrolflag is ON then char above draws only to host
{                                                          // and this function outputs all data at once when string is done
int length,index;
int err;


	length=stringPixels(strptr);
	if(!(FontControlFlag&1))//direction is horizontal
	{
		if(x+length>lcdWidth-1)
		{
			err=-4;
			return(err);
		}
		if(y+fontHeight>lcdHeight-1)
		{
			err=-3;
			return(err);
		}
	}
	else // direction is vertical
	{
		if(x+fontWidth>=lcdWidth-1)
		{
			err=-2;
			return(err);
		}
		if(y+length>lcdHeight-1)
		{
			err=-4;
			return(err);
		}
	}
	GraphicsControlFlag |= BITBLIT;
	length=strlen(strptr);
	for(index=0;index<length;++index)
	{
		switch((FontControlFlag&1))
		{
			case HORIZONTAL :
				lcddrawChar(x+(index*fontWidth),y,(strptr+index));
				break;
			case VERTICAL :
				lcddrawChar(x,y+(index*fontHeight),(strptr+index));
				break;
			default :
				break;
		}
	}

	GraphicsControlFlag ^= BITBLIT;
	switch((FontControlFlag&1))
	{
		case HORIZONTAL :
			bitBlt(x,y,x+(fontWidth*length),y+fontHeight);
			break;
		case VERTICAL :
			bitBlt(x,y,x+fontWidth,y+(fontHeight*length));
			break;
		default :
			break;
	}
	return(0);
}

int lcddrawTriangle(word x0,word y0,word radius,byte type,word ang1,word ang2,word ang3)
{
int x,y;
double radian;

	if((x0<0) || (x0>lcdWidth-1))
		return(-6);
	if((y0<0) || (y0>lcdHeight-1))
		return(-7);
	if((x0-radius<0) || (x0+radius>lcdWidth-1))
		return(-6);
	if((y0-radius<0) || (y0 +radius>lcdHeight-1))
		return(-7);
	//GraphicsControlFlag |= BITBLIT;
	//lcddrawCircle(x0,y0,100,Nofill);
	lcddrawHline(x0-10,x0+10,y0);
	lcddrawVline(x0,y0-10,y0+10);
	radian=deg2rad((float)ang1);
	x=cos(radian)*(double)radius;
	y=sin(radian)*(double)radius;
	//radian=deg2rad((float)ang1);
	//x=cos(radian)*(double)radius;
	//y=sin(radian)*(double)radius;
	//lcdOffset(x0+x,y0-y);
	triangle[0][0]=x0+x;
	triangle[0][1]=y0-y;
	radian=deg2rad((float)(ang1+ang2));
	x=cos(radian)*(double)radius;
	y=sin(radian)*(double)radius;
	//lcdOffset(x0+x,y0-y);
	triangle[1][0]=x0+x;
	triangle[1][1]=y0-y;
	radian=deg2rad((float)(ang1+ang2+ang3));
	x=cos(radian)*(double)radius;
	y=sin(radian)*(double)radius;
	//lcdOffset(x0+x,y0-y);
	triangle[2][0]=x0+x;
	triangle[2][1]=y0-y;
	lcddrawLine(triangle[0][0],triangle[0][1],triangle[1][0],triangle[1][1]);
	lcddrawLine(triangle[1][0],triangle[1][1],triangle[2][0],triangle[2][1]);
	lcddrawLine(triangle[2][0],triangle[2][1],triangle[0][0],triangle[0][1]);
	//GraphicsControlFlag ^= BITBLIT;
	//bitBlt(x0-radius,y0-radius,x0+radius,y0+radius);
	return(0);
}

//************************ End functions *******************************

int main(int argc,char *argv[])
{
char initPath[255];
word z;

clock_t start,end;
float time;
char ch[2];
int x,lin,ccount,bytesRead;
char teststr[40];
byte *savptr;
int initFD;
struct display_data
{
	word init_size;
	word width;
	word height;
}display_data;


	gpioOpen();//opens file to gpiomem
	gpioPins();// uses file fd above to associate file and 'Broadcom pin number,direction,and intial values
	printf("Gpio pins initialized.\n");

	if(argc>1)
	{
		memset(initList,255,sizeof(initList));
		initParamCount=argc;
		printf("Number of parameters %d\n",argc-1);
		for(x=1;x<initParamCount;++x)
		{
			initList[x]=0;
		}
		x=1;
		while(x<(initParamCount))
		{
			if(initList[x]==0)
			{

				for(z=0;z<iliLCDs;++z)
				{
					if((strcasecmp(argv[x],iliChips[z])==0))
					{
						iliINITindex=z;
						initList[x]=255;
						++x;
						goto LOOP;
					}
				}
				for(z=0;z<ILIparams;++z)
				{
					if((strcasecmp(argv[x],"DC")==0))
					{
						DC=atoi(argv[z+x+1]);
						initList[x]=255;
						initList[x+1]=255;
						x+=2;
						goto LOOP;
					}
					if((strcasecmp(argv[x],"RESET")==0))
					{
						RESET=atoi(argv[z+x+1]);
						initList[x]=255;
						initList[x+1]=255;
						x+=2;
						goto LOOP;
					}
					if((strcasecmp(argv[x],"LED")==0))
					{
						LED=atoi(argv[z+x+1]);
						initList[x]=255;
						initList[x+1]=255;
						x+=2;
						goto LOOP;
					}
					if((strcasecmp(argv[x],"BGR")==0))
					{
						bgr=atoi(argv[z+x+1]);
						initList[x]=255;
						initList[x+1]=255;
						GraphicsControlFlag |= 0x80;
						x+=2;
						goto LOOP;
					}
					if((strcasecmp(argv[x],"ROTATE")==0))
					{
						//ROTATE=atoi(argv[x+1]);
						rotateAngle=atoi(argv[x+1]);
						GraphicsControlFlag |= 0x80;
						initList[x]=255;
						initList[x+1]=255;
						x+=2;
						goto LOOP;
					}// end if ROTATE argument;
					if(((strcasecmp(argv[x],"?")==0)) || ((strcasecmp(argv[x],"H")==0)))
					{
						printf("Init file to use ie.Ili9431,Ili9486 etc.\n");
						printf("All pins use the Broadcom pin number ie. GPIO(18) only use the number.\n");
						printf("DC [Pin number] must include the space(s) they are delimiters.\n");
						printf("RESET [Pin number]\n");
						printf("LED [Pin number]\n");
						printf("ROTATE [Pin number]\n");
						printf("? or H displays these messages.\n");
						printf("Ordering and capitalization is unimportant.\n");
						EXIT(0);
					}
				}
			}
			else
				++x;
			LOOP:;

		}// end parameter loop
		printf("Display       %s\n",iliChips[iliINITindex]);
		printf("DC    GPIO =  %d\n",DC);
		printf("RESET GPIO =  %d\n",RESET);
		printf("LED   GPIO =  %d\n",LED);
		printf("Rotation      %d\n",ROTATE);
		//
		printf("lcdWidth = %d  lcdHeight = %d\n",lcdWidth,lcdHeight);
	}//end if args
	else
	{
		printf("Default display       %s\n",iliChips[iliINITindex]);
		printf("Default DC    GPIO =  %d\n",DC);
		printf("Default RESET GPIO =  %d\n",RESET);
		printf("Default LED   GPIO =  %d\n",LED);
		printf("Default Rotation      %d\n",ROTATE);
		//printf("lcdWidth = %d  lcdHeight = %d\n",lcdWidth,lcdHeight);
		printf("Proceed using default values Y/N + [enter]\n");
		ch[0]=0x0;
		while(1)
		{
			ch[0]=getchar();
			if((ch[0]=='y') || (ch[0]=='Y'))
				break;
			if((ch[0]=='n') || (ch[0]=='N'))
			{
				printf("After program name [SPACE] then ? or h or H for help to override defaults.\n");
				EXIT(0);
			}
		}
	}//end all to do with program arguments
	strcpy(initPath,"/home/pi/IliTek_Displays/Init_Code/");
	strcat(initPath,iliINIT[iliINITindex]);
	printf("Opening init file %s\n",initPath);
	initFD=open(initPath,O_RDONLY);
	if(initFD<0)
	{
		printf("Fatal! Failed to open %s\n",iliINIT[iliINITindex]);
		printf("%s\n",strerror(errno));
		EXIT(6);
	}
	bytesRead=read(initFD,&display_data,sizeof(display_data));
	if(bytesRead<6)
	{
		printf("Fatal! Failed to Read %s\n",iliINIT[iliINITindex]);
		EXIT(7);
	}
	z=display_data.init_size;
	bytesRead=read(initFD,iliINITcode,z);
	close(initFD);
	if(bytesRead<z)
	{
		printf("Fatal! Failed to open %s\n",iliINIT[iliINITindex]);
		EXIT(7);
	}
	printf("Read %d bytes of init code\n",bytesRead);
	INITBYTES=display_data.init_size;
	lcdWidth=display_data.width;
	lcdHeight=display_data.height;
	gptr=malloc(lcdWidth*lcdHeight*3);// 18 bit color ie 3 bytes per pixel HOST memory buffer
	if(gptr==NULL)
	{
		printf("Unable to allocate Host memory. Aborting\n");
		EXIT(1);
	}
	GPTR=gptr;
	Rxptr=malloc(4096);// spi duplex recieve buffer
	if(Rxptr==NULL)
	{
		printf("Unable to allocate readback buffer. Aborting\n");
		EXIT(1);
	}
	RXPTR=Rxptr;
	memset(gptr,0,lcdWidth*lcdHeight*3);
	memset(Rxptr,0xff,4096);
	lcdFD=SPISetup ("ILI9488",32); //opens spidevX.X
	if(lcdFD<0)
	{
		printf("Failed to open SPI! Aborting\n");
		EXIT(1);
	}
	printf("SPI opened for Display\n");
	scanlinebytes=lcdWidth*3;
	bytesperscreen=scanlinebytes*lcdHeight;
	strcpy(fontPath,"/home/pi/IliTek_Displays/Fonts/f12x24.fbm");//12x24
	kbinit();// sets up console for non-blocking keyboard reads
	memset(font,0,(sizeof(font)));
	fontFD=fopen(fontPath,"r");
	if(fontFD==NULL)
	{
		printf("Unable to load font %s file. Aborting\n",fontPath);
		EXIT(1);
	}
	else
		fread(font,sizeof(byte),12292,fontFD);//needs some fixing for differing font sizes
	printf("Font is loaded\n");
	fclose(fontFD);
	fontFD=NULL;
	fontWidth=font[0];
	fontHeight=font[1];
	ch[0]='A';
	ch[1]=0x0;
	strcpy(teststr,"HAppy Days :-)");
	printf("Initializing the display\n");
	hardReset();
	lcdinitPanel();
	if(GraphicsControlFlag &0x80) // reset orientation here if command line parameter changes default
	{
		lcdBGR=bgr;
		lcdOrientation(rotateAngle);
		GraphicsControlFlag ^= 0x80;
	}
	GraphicsControlFlag=0;
	color18(Background,0xffffff);
	color18(Foreground,0xff0000);
	color18(Textcolor,0x0000ff);
	color18(TextBkcolor,0xff0000);
	printf("Clearing the display\n");
	start=clock();
	lcdClear();
	end=clock();
	time=((float)end-start)/CLOCKS_PER_SEC;
	printf("Time to clear display %.6f mS\n",time*1000);
	printf("Frquency       =      %.2f  Hz\n\n",1.0/time);
	lcdon();
	x=0;
	//GraphicsControlFlag |= BITBLIT;
	savptr=lcdsaveArea(lcdWidth/2-100,lcdHeight/2-100,lcdWidth/2+100,lcdHeight/2+100);
	start=clock();
	lcdrestoreArea(lcdWidth/2-100,lcdHeight/2-100,savptr);
	end=clock();
	time=((float)(end-start))/CLOCKS_PER_SEC;
	printf("ticks %.6f\n",time);
	sleep(5);
	while(!(kbhit()))
	//for(x=0;x<=360;x+=5)
	{
		//savptr=lcdsaveArea(lcdWidth/2-100,lcdHeight/2-100,lcdWidth/2+100,lcdHeight/2+100);
		lcddrawTriangle(lcdWidth/2,lcdHeight/2,100,0,x,120,120);
		usleep(250000);
		color18(Foreground,0xffffff);
		lcddrawTriangle(lcdWidth/2,lcdHeight/2,100,0,x,120,120);
		color18(Foreground,0xff0000);
		//lcdclearArea(lcdWidth/2-100,lcdHeight/2-100,lcdWidth/2+100,lcdHeight/2+100);
		//writeCommand(0x0);
		//writeCommand(0x28);
		//lcdrestoreArea(lcdWidth/2-100,lcdHeight/2-100,savptr);
		//writeCommand(0x29);
		//free(savptr);
		x+=5;
		x %=360;
	}
	free(savptr);
	//GraphicsControlFlag ^= BITBLIT;
	/*
	printf("Drawing a single character.\n");
	lcddrawChar((lcdWidth/2)-(fontWidth/2),(lcdHeight/2)-(fontHeight/2),ch);
	sleep(3);
	start=clock();
	printf("Draw 4 horizontal strings differing attributes.\n");
	lcddrawString(5,10,teststr);
	FontControlFlag=0;
	FontControlFlag |= CH_BG;
	lcddrawString(5,10+(fontHeight*2),teststr);
	FontControlFlag=0;
	FontControlFlag |= CH_INV;
	lcddrawString(5,10+(fontHeight*4),teststr);
	FontControlFlag=0;
	FontControlFlag |= CH_UL;
	FontControlFlag |= CH_ONLY;
	lcddrawString(5,10+(fontHeight*6),teststr);
	FontControlFlag=3;
	end=clock();
	time=((float)end-start)/CLOCKS_PER_SEC;
	printf("Time to draw string   %.6f mS\n",time*1000);
	printf("Frquency       =      %.2f  Hz\n\n",1.0/time);
	sleep(5);
	strcpy(teststr,"Bunny");
	printf("Drawing a vertical string\n");
	lcddrawString(lcdWidth-(fontWidth*2),10,teststr);
	FontControlFlag=2;
	sleep(3);
	printf("Clearing the display\n");
	lcdClear();
	//lcdOrientation(0);// ORIENTATION CHANGE 0 , 90 , 180 , 270
	printf("Drawing a horizontal line.\n");
	start=clock();
	lcddrawHline(0,lcdWidth-1,lcdHeight/2);
	end=clock();
	time=((float)(end-start))/CLOCKS_PER_SEC;
	printf("Time to draw horizontal line            %.2f  mS\n",time*1000);
	printf("Frquency                =               %.2f  Hz\n\n",1.0/time);
	sleep(3);
	printf("Drawing a vertical line.\n");
	lcddrawVline(lcdWidth/2,0,lcdHeight-1);
	sleep(3);
	printf("Drawing a filled rectangle\n");
	lcddrawRectangle(50,lcdHeight/2-50,100,lcdHeight/2+50,Fill);
	sleep(3);
	printf("Drawing a rectangle\n");
	lcddrawRectangle(lcdWidth-50,lcdHeight/2,lcdWidth-1,lcdHeight/2+50,Nofill);
	sleep(3);
	printf("Saving rectangle prior to being painted'\n");
	savptr=lcdsaveArea(50,lcdHeight/2-50,100,lcdHeight/2+50);
	color18(Foreground,0xff00ff);
	printf("Painting previous rectangle.\n");
	lcddrawRectangle(50,lcdHeight/2-50,100,lcdHeight/2+50,Fill);
	sleep(3);
	if(savptr!=NULL)
	{
		printf("Restoring previous rectangle color.\n");
		lcdrestoreArea(50,lcdHeight/2-50,savptr);
		free(savptr);
	}
	sleep(3);
	printf("Clearing previous rectangle.\n");
	lcdclearArea(50,lcdHeight/2-50,100,lcdHeight/2+50);
	sleep(3);
	printf("Invert ON\n");
	lcdInvert(ON);
	sleep(3);
	printf("Invert OFF\n");
	lcdInvert(OFF);
	sleep(3);
	printf("Clearing the display\n");
	lcdClear();
	printf("Draw circle\n");
	start=clock();
	lcddrawCircle(lcdWidth/2,lcdHeight/2,100,Nofill);
	end=clock();
	time=((float)end-start)/CLOCKS_PER_SEC;
	printf("Time to display  circle       =         %.6f mS\n",time*1000);
	printf("Frquency                =               %.2f  Hz\n\n",1.0/time);
	sleep(3);
	//printf("Clearing the display\n");
	//lcdClear();
	color18(Foreground,0xff0000);
	printf("Draw diagonals line\n");
	lcddrawLine(0,0,lcdWidth-1,lcdHeight-1);
	sleep(3);
	//color18(Foreground,0x000000);
	lcddrawLine(0,lcdHeight-1,lcdWidth-1,0);
	sleep(3);
	printf("Clearing the display\n");
	lcdClear();
	color18(Foreground,0xff00ff);
	printf("Draw ellipse\n");
	start=clock();
	lcddrawEllipse(lcdWidth/2,lcdHeight/2,(lcdWidth/4),(lcdHeight/2-2),Nofill);
	end=clock();
	time=((float)(end-start))/CLOCKS_PER_SEC;
	printf("Time to display ellipse 200 x 310       %.2f  mS\n",time*1000);
	printf("Frquency                =               %.2f  Hz\n\n",1.0/time);
	sleep(3);
	printf("Drawing horizontal with pixels.\n");
	start=clock();
	for(x=0;x<=lcdWidth-1;++x)
		lcdPutpixel(x,lcdHeight/2);
	end=clock();
	time=((float)(end-start))/CLOCKS_PER_SEC;
	printf("Time to display line with pixels lcdWidth   %.2f  mS\n",time*1000);
	printf("Frquency                =                   %.2f  Hz\n\n",1.0/time);
	sleep(3);
	printf("Clearing the display\n");
	lcdClear();

	printf("Drawing arc of any angle may be open or closed no fill at this time.\n");
	lcddrawArc(lcdWidth/2,lcdHeight/2,30,240,100,ClosedArc);
	sleep(3);
	printf("Clearing the display\n");
	lcdClear();
	GraphicsControlFlag |= BITBLIT;
	ccount=0;
	lin=10;
	x=0;
	start=clock();
	while(ccount<256)
	{
		lcddrawChar(x,lin,(char*)&ccount);
		++ccount;
		x+=fontWidth;
		if(x>=lcdWidth)
		{
			x=0;
			lin+=fontHeight;
			if(lin+fontHeight>lcdHeight-1)
			{
				bitBlt(0,0,lcdWidth-1,lcdHeight-1);
				sleep(3);
				lin=10;
				x=0;
				printf("Clearing the display\n");
				lcdClear();
			}
		}
	}
	printf("Refreshing the display\n");
	lcdRefresh();
	end=clock();
	GraphicsControlFlag ^= BITBLIT;
	time=((float)end-start)/CLOCKS_PER_SEC;
	printf("Time to draw character set      =       %.6f mS\n",time*1000);
	printf("Frquency                =               %.2f  Hz\n\n",1.0/time);
	printf("Pixel color is %06x\n",lcdGetpixel(lcdWidth/2,lcdHeight-1));
	*/
	printf("Press any key to quit\n");
	while(!(kbhit()))
		;
	EXIT(0);
	return(0);
}
