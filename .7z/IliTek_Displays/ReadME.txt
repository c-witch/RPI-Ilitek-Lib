	

	Please before anything else open the documentation in the doc's folder and
read it before going any further.